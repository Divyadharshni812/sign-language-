from flask import Flask, jsonify
import threading
import gesture_engine

app = Flask(__name__)

@app.route("/gesture")
def get_gesture():
    return jsonify({"gesture": gesture_engine.current_gesture})

if __name__ == "__main__":
    t = threading.Thread(target=gesture_engine.run, daemon=True)
    t.start()

    print("🟢 Backend running at http://127.0.0.1:5000")
    app.run(port=5000, debug=False, use_reloader=False)
