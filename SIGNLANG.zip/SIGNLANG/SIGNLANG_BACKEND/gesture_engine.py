import cv2
import mediapipe as mp
import pyttsx3
import time

mp_hands = mp.solutions.hands
hands = mp_hands.Hands(max_num_hands=2)
mp_draw = mp.solutions.drawing_utils

engine = pyttsx3.init()
engine.setProperty("rate", 160)

cap = cv2.VideoCapture(0)

current_gesture = "None"
last_spoken = ""
last_time = 0

def count_fingers(hand_landmarks, handedness):
    tips = [4, 8, 12, 16, 20]
    fingers = []

    if handedness == "Right":
        fingers.append(hand_landmarks.landmark[4].x < hand_landmarks.landmark[3].x)
    else:
        fingers.append(hand_landmarks.landmark[4].x > hand_landmarks.landmark[3].x)

    for tip in tips[1:]:
        fingers.append(
            hand_landmarks.landmark[tip].y <
            hand_landmarks.landmark[tip - 2].y
        )

    return sum(fingers)

def map_gesture(count):
    return {
        1: "HELLO",
        2: "YES",
        3: "NO",
        4: "THANK YOU",
        5: "PLEASE"
    }.get(count, "None")

def run():
    global current_gesture, last_spoken, last_time

    print("✋ Camera running — show gesture")

    while True:
        success, frame = cap.read()
        if not success:
            continue

        frame = cv2.flip(frame, 1)
        rgb = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
        result = hands.process(rgb)

        gesture = "None"

        if result.multi_hand_landmarks and result.multi_handedness:
            for handLms, handType in zip(result.multi_hand_landmarks,
                                          result.multi_handedness):

                mp_draw.draw_landmarks(frame, handLms, mp_hands.HAND_CONNECTIONS)
                hand_label = handType.classification[0].label
                fingers = count_fingers(handLms, hand_label)
                gesture = map_gesture(fingers)

        current_gesture = gesture

        if gesture != "None" and gesture != last_spoken:
            if time.time() - last_time > 2:
                engine.say(gesture)
                engine.runAndWait()
                last_spoken = gesture
                last_time = time.time()

        cv2.imshow("SIGNLANG", frame)
        if cv2.waitKey(1) & 0xFF == ord('q'):
            break

    cap.release()
    cv2.destroyAllWindows()
