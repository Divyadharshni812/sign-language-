setInterval(async () => {
  try {
    const res = await fetch("http://127.0.0.1:5000/gesture");
    const data = await res.json();
    document.getElementById("gesture").innerText = data.gesture;
  } catch {
    document.getElementById("gesture").innerText = "Backend not running";
  }
}, 700);
